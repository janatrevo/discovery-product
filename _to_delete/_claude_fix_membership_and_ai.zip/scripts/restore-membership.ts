/**
 * Restaura o vínculo (project_memberships) de um usuário com o projeto que
 * ele mesmo criou, caso tenha sido removido por engano (ex.: bug do
 * removeMember que permitia remover o último Owner — já corrigido). Não cria
 * projeto novo nem apaga nada: só reconecta a conta ao projeto existente
 * (com todos os dados já lá), como Owner.
 *
 * Uso: node --env-file-if-exists=.env.local --env-file-if-exists=.env --import tsx scripts/restore-membership.ts seu-email@exemplo.com
 */
import { db } from "../src/db";
import { eq, and } from "drizzle-orm";
import { users, projects, projectMemberships } from "../src/db/schema";

async function main() {
  const email = process.argv[2];
  if (!email) {
    console.log("Uso: ... scripts/restore-membership.ts seu-email@exemplo.com");
    process.exit(1);
  }

  const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
  if (!user) {
    console.log(`Nenhum usuário encontrado com o e-mail "${email}".`);
    process.exit(1);
  }
  console.log(`Usuário encontrado: ${user.name} <${user.email}> (id: ${user.id})`);

  const existingMemberships = await db
    .select()
    .from(projectMemberships)
    .where(eq(projectMemberships.userId, user.id));
  if (existingMemberships.length > 0) {
    console.log(
      `Esta conta já tem ${existingMemberships.length} vínculo(s) de projeto — nada para restaurar. ` +
        `Se o erro "Nenhum projeto disponível" ainda aparecer, pode ser outra causa; me avise.`
    );
    process.exit(0);
  }

  const ownedProjects = await db.select().from(projects).where(eq(projects.createdBy, user.id));
  if (ownedProjects.length === 0) {
    console.log(
      `Não encontrei nenhum projeto criado por esta conta (createdBy = ${user.id}). ` +
        `Rode scripts/diagnose-account.ts primeiro para ver todos os projetos existentes e me avise o resultado.`
    );
    process.exit(1);
  }

  for (const project of ownedProjects) {
    const [already] = await db
      .select()
      .from(projectMemberships)
      .where(and(eq(projectMemberships.projectId, project.id), eq(projectMemberships.userId, user.id)))
      .limit(1);
    if (already) continue;
    await db.insert(projectMemberships).values({ projectId: project.id, userId: user.id, role: "owner" });
    console.log(`Restaurado: ${user.email} agora é Owner de novo do projeto "${project.name}" (id: ${project.id}).`);
  }

  console.log("Concluído. Recarregue a aplicação — o projeto e todos os dados devem aparecer normalmente.");
}

main()
  .then(() => process.exit(0))
  .catch((err) => {
    console.error("Erro ao restaurar vínculo:", err);
    process.exit(1);
  });
