import { test, expect } from "@playwright/test";
import { signup, uniqueEmail, fieldByLabel } from "./helpers";

test("cria um produto/conceito e ele aparece na lista", async ({ page }) => {
  test.setTimeout(60_000);
  const email = uniqueEmail("owner-product");
  await signup(page, { name: "QA Product Owner", email, password: "SenhaForte123", orgName: "QA Product Org" });

  await page.goto("/products/new");
  await fieldByLabel(page, "Nome").fill("App de agendamento de consultas");
  await page.getByRole("button", { name: "Criar" }).click();
  await expect(page).toHaveURL(/\/products\/[0-9a-f-]{36}/, { timeout: 15_000 });
  await expect(page.getByText("App de agendamento de consultas")).toBeVisible();

  await page.goto("/products");
  await expect(page.getByText("App de agendamento de consultas")).toBeVisible();
});
