"use client";

import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import clsx from "clsx";
import {
  LayoutDashboard,
  Lightbulb,
  Target,
  Users,
  Package,
  Library,
  FlaskConical,
  ScrollText,
  FileBarChart,
  Settings,
} from "lucide-react";

const NAV = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/hypotheses", label: "Hypotheses", icon: Lightbulb },
  { href: "/opportunities", label: "Discovery Board", icon: Target },
  { href: "/personas", label: "Personas", icon: Users },
  { href: "/products", label: "Products & Concepts", icon: Package },
  { href: "/research", label: "Research & Testing", icon: FlaskConical },
  { href: "/repository", label: "Research Repository", icon: Library },
  { href: "/decisions", label: "Decision Log", icon: ScrollText },
  { href: "/reports", label: "Reports", icon: FileBarChart },
  { href: "/settings", label: "Settings", icon: Settings },
];

export function Sidebar() {
  const pathname = usePathname();
  return (
    <aside
      className="flex w-60 shrink-0 flex-col text-white"
      style={{ background: "linear-gradient(180deg, #8B42FF 0%, #6518E5 100%)" }}
    >
      <div className="flex h-14 items-center px-4">
        <Image src="/trevo-logo.png" alt="Trevo" width={110} height={25} priority className="h-6 w-auto" />
      </div>
      <nav className="flex-1 space-y-0.5 overflow-y-auto p-3">
        {NAV.map((item) => {
          const active = pathname === item.href || pathname.startsWith(item.href + "/");
          const Icon = item.icon;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={clsx(
                "flex items-center gap-2.5 rounded-md px-3 py-2 text-sm font-medium transition-colors",
                active ? "bg-white/20 text-white" : "text-white/70 hover:bg-white/10 hover:text-white"
              )}
            >
              <Icon size={16} strokeWidth={2} />
              {item.label}
            </Link>
          );
        })}
      </nav>
      <div className="border-t border-white/15 p-3 text-[11px] leading-snug text-white/60">
        Simulação de IA nunca conta como evidência. Veja sempre a origem do dado antes de decidir.
      </div>
    </aside>
  );
}
