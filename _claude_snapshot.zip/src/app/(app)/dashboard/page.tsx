import { getPageContext } from "@/lib/page-context";
import { db } from "@/db";
import { hypotheses, personas, products, evidence, experiments, opportunities, decisions } from "@/db/schema";
import { eq, sql, and } from "drizzle-orm";
import { Card, PageHeader } from "@/components/ui/primitives";
import Link from "next/link";

export default async function DashboardPage() {
  const { project } = await getPageContext();
  const pid = project.id;

  const [statusCounts] = await Promise.all([
    db
      .select({ status: hypotheses.status, count: sql<number>`count(*)::int` })
      .from(hypotheses)
      .where(eq(hypotheses.projectId, pid))
      .groupBy(hypotheses.status),
  ]);

  const countBy = (status: string) => statusCounts.find((s) => s.status === status)?.count ?? 0;
  const totalHypotheses = statusCounts.reduce((acc, s) => acc + s.count, 0);

  const [{ count: personaCount }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(personas)
    .where(eq(personas.projectId, pid));

  const [{ count: productCount }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(products)
    .where(eq(products.projectId, pid));

  const [{ count: evidenceCount }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(evidence)
    .where(eq(evidence.projectId, pid));

  const [{ count: simulationOnlyEvidence }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(evidence)
    .where(and(eq(evidence.projectId, pid), eq(evidence.originClass, "simulation")));

  const [{ count: experimentsInProgress }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(experiments)
    .where(and(eq(experiments.projectId, pid), eq(experiments.status, "in_progress")));

  const [{ count: opportunityCount }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(opportunities)
    .where(eq(opportunities.projectId, pid));

  const [{ count: decisionCount }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(decisions)
    .where(eq(decisions.projectId, pid));

  const simPct = evidenceCount > 0 ? Math.round((simulationOnlyEvidence / evidenceCount) * 100) : 0;

  const stats = [
    { label: "Hipóteses totais", value: totalHypotheses, href: "/hypotheses" },
    { label: "Validadas", value: countBy("validated"), href: "/hypotheses?status=validated" },
    { label: "Parcialmente validadas", value: countBy("partially_validated"), href: "/hypotheses?status=partially_validated" },
    { label: "Invalidadas", value: countBy("invalidated"), href: "/hypotheses?status=invalidated" },
    { label: "Em investigação", value: countBy("investigating"), href: "/hypotheses?status=investigating" },
    { label: "Sem evidência", value: countBy("not_tested"), href: "/hypotheses?status=not_tested" },
    { label: "Inconclusivas", value: countBy("inconclusive"), href: "/hypotheses?status=inconclusive" },
  ];

  return (
    <div>
      <PageHeader
        title="Discovery Dashboard"
        description={`Visão geral de ${project.name}`}
      />

      <div className="mb-4 grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-6">
        {stats.map((s) => (
          <Link key={s.label} href={s.href}>
            <Card className="transition-shadow hover:shadow-md">
              <p className="text-2xl font-semibold text-slate-900">{s.value}</p>
              <p className="mt-1 text-xs text-slate-500">{s.label}</p>
            </Card>
          </Link>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-4">
        <Card>
          <p className="text-2xl font-semibold text-slate-900">{personaCount}</p>
          <p className="mt-1 text-xs text-slate-500">Personas</p>
        </Card>
        <Card>
          <p className="text-2xl font-semibold text-slate-900">{productCount}</p>
          <p className="mt-1 text-xs text-slate-500">Produtos/Conceitos</p>
        </Card>
        <Card>
          <p className="text-2xl font-semibold text-slate-900">{experimentsInProgress}</p>
          <p className="mt-1 text-xs text-slate-500">Experimentos em andamento</p>
        </Card>
        <Card>
          <p className="text-2xl font-semibold text-slate-900">{decisionCount}</p>
          <p className="mt-1 text-xs text-slate-500">Decisões registradas</p>
        </Card>
      </div>

      <Card className={`mt-4 ${simPct > 40 ? "border-amber-300 bg-amber-50" : ""}`}>
        <p className="text-sm font-medium text-slate-700">
          % de evidência que é apenas simulação de IA:{" "}
          <span className={simPct > 40 ? "text-amber-700" : "text-slate-900"}>{simPct}%</span>
        </p>
        <p className="mt-1 text-xs text-slate-500">
          Este é o indicador de saúde mais importante do processo de discovery — simulação nunca
          conta para o Confidence Score. Se este número estiver alto, é sinal de que decisões podem
          estar se apoiando em exploração de IA em vez de pesquisa real com usuários.
        </p>
      </Card>

      <Card className="mt-4">
        <p className="text-sm font-medium text-slate-700">Discovery Board</p>
        <p className="mt-1 text-xs text-slate-500">{opportunityCount} oportunidades mapeadas.</p>
        <Link href="/opportunities" className="mt-2 inline-block text-xs font-medium text-indigo-600">
          Ver Discovery Board →
        </Link>
      </Card>
    </div>
  );
}
