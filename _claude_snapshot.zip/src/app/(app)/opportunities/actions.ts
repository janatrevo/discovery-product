"use server";

import { db } from "@/db";
import { opportunities, hypotheses } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getPageContext } from "@/lib/page-context";
import { computePriorityScore } from "@/lib/priority-score";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";

function readScores(formData: FormData) {
  const num = (name: string, fallback = 3) => {
    const v = Number(formData.get(name));
    return Number.isFinite(v) && v >= 1 && v <= 5 ? v : fallback;
  };
  return {
    impact: num("impact"),
    frequency: num("frequency"),
    severity: num("severity"),
    businessPotential: num("businessPotential"),
    solutionEase: num("solutionEase"),
  };
}

export async function createOpportunity(formData: FormData) {
  const { user, project, role } = await getPageContext();
  if (role === "viewer") throw new Error("Viewers não podem criar oportunidades.");

  const hypothesisId = String(formData.get("hypothesisId") || "") || null;
  const personaId = String(formData.get("personaId") || "") || null;
  const scores = readScores(formData);

  let evidenceConfidence = 0;
  if (hypothesisId) {
    const [hyp] = await db.select().from(hypotheses).where(eq(hypotheses.id, hypothesisId)).limit(1);
    if (hyp?.confidenceScore) evidenceConfidence = Number(hyp.confidenceScore);
  }

  const priorityScore = computePriorityScore({ ...scores, evidenceConfidence });

  const [created] = await db
    .insert(opportunities)
    .values({
      projectId: project.id,
      hypothesisId,
      personaId,
      title: String(formData.get("title") || ""),
      description: String(formData.get("description") || ""),
      problemRef: String(formData.get("problemRef") || ""),
      ...scores,
      evidenceConfidence: Math.round(evidenceConfidence),
      priorityScore: String(priorityScore),
      createdBy: user.id,
    })
    .returning();

  revalidatePath("/opportunities");
  redirect(`/opportunities/${created.id}`);
}

export async function updateOpportunityStatus(opportunityId: string, formData: FormData) {
  const { role } = await getPageContext();
  if (role === "viewer") throw new Error("Sem permissão.");
  const status = String(formData.get("status") || "new") as never;
  await db.update(opportunities).set({ status }).where(eq(opportunities.id, opportunityId));
  revalidatePath("/opportunities", "layout");
}

export async function updateOpportunityScores(opportunityId: string, formData: FormData) {
  const { role } = await getPageContext();
  if (role === "viewer") throw new Error("Sem permissão.");

  const [existing] = await db.select().from(opportunities).where(eq(opportunities.id, opportunityId)).limit(1);
  if (!existing) throw new Error("Oportunidade não encontrada.");

  const scores = readScores(formData);
  const priorityScore = computePriorityScore({ ...scores, evidenceConfidence: existing.evidenceConfidence });

  await db
    .update(opportunities)
    .set({
      title: String(formData.get("title") || existing.title),
      description: String(formData.get("description") || existing.description || ""),
      ...scores,
      priorityScore: String(priorityScore),
    })
    .where(eq(opportunities.id, opportunityId));

  revalidatePath(`/opportunities/${opportunityId}`);
  revalidatePath("/opportunities");
}
