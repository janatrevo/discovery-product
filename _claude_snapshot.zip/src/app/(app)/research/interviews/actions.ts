"use server";

import { db } from "@/db";
import { interviewGuides, interviewGuideQuestions, interviews, codes, codedSegments } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getPageContext } from "@/lib/page-context";
import { linesToArray } from "@/lib/list-utils";
import { suggestCodes } from "@/lib/ai";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";

export async function createGuide(formData: FormData) {
  const { user, project, role } = await getPageContext();
  if (role === "viewer") throw new Error("Sem permissão.");
  const hypothesisId = String(formData.get("hypothesisId") || "") || null;

  const [guide] = await db
    .insert(interviewGuides)
    .values({
      projectId: project.id,
      hypothesisId,
      title: String(formData.get("title") || ""),
      objective: String(formData.get("objective") || ""),
      scenario: String(formData.get("scenario") || ""),
      jtbdContext: String(formData.get("jtbdContext") || ""),
      jtbdMotivation: String(formData.get("jtbdMotivation") || ""),
      jtbdObstacle: String(formData.get("jtbdObstacle") || ""),
      jtbdExpectedOutcome: String(formData.get("jtbdExpectedOutcome") || ""),
      createdBy: user.id,
    })
    .returning();

  const questionLines = linesToArray(formData.get("questions"));
  if (questionLines.length) {
    await db.insert(interviewGuideQuestions).values(
      questionLines.map((q, idx) => ({ guideId: guide.id, orderIndex: idx, questionText: q }))
    );
  }

  revalidatePath("/research/interviews");
  redirect(`/research/interviews/${guide.id}`);
}

export async function logInterview(guideId: string, formData: FormData) {
  const { user, project, role } = await getPageContext();
  if (role === "viewer") throw new Error("Sem permissão.");

  const [interview] = await db
    .insert(interviews)
    .values({
      projectId: project.id,
      guideId,
      personaId: String(formData.get("personaId") || "") || null,
      intervieweeRef: String(formData.get("intervieweeRef") || ""),
      transcript: String(formData.get("transcript") || ""),
      createdBy: user.id,
    })
    .returning();

  revalidatePath(`/research/interviews/${guideId}`);
  redirect(`/research/interviews/${guideId}/interview/${interview.id}`);
}

export async function createCode(projectId: string, name: string) {
  const [existing] = await db.select().from(codes).where(eq(codes.name, name)).limit(1);
  if (existing) return existing;
  const [created] = await db.insert(codes).values({ projectId, name }).returning();
  return created;
}

export async function addCodedSegment(interviewId: string, formData: FormData) {
  const { user, project, role } = await getPageContext();
  if (role === "viewer") throw new Error("Sem permissão.");

  let codeId = String(formData.get("codeId") || "");
  const newCodeName = String(formData.get("newCodeName") || "").trim();
  if (!codeId && newCodeName) {
    const created = await createCode(project.id, newCodeName);
    codeId = created.id;
  }
  if (!codeId) throw new Error("Selecione ou crie um código.");

  await db.insert(codedSegments).values({
    interviewId,
    codeId,
    excerpt: String(formData.get("excerpt") || ""),
    aiSuggested: false,
    confirmed: true,
    isRepresentativeQuote: formData.get("isQuote") === "true",
    createdBy: user.id,
  });
  revalidatePath(`/research/interviews`, "layout");
}

export async function confirmSegment(segmentId: string) {
  const { role } = await getPageContext();
  if (role === "viewer") throw new Error("Sem permissão.");
  await db.update(codedSegments).set({ confirmed: true }).where(eq(codedSegments.id, segmentId));
  revalidatePath(`/research/interviews`, "layout");
}

export async function deleteSegment(segmentId: string) {
  const { role } = await getPageContext();
  if (role === "viewer") throw new Error("Sem permissão.");
  await db.delete(codedSegments).where(eq(codedSegments.id, segmentId));
  revalidatePath(`/research/interviews`, "layout");
}

export async function runAiCodeSuggestion(interviewId: string) {
  const { user, project, role } = await getPageContext();
  if (role === "viewer") throw new Error("Sem permissão.");

  const [interview] = await db.select().from(interviews).where(eq(interviews.id, interviewId)).limit(1);
  if (!interview?.transcript) return;

  const existingCodes = await db.select().from(codes).where(eq(codes.projectId, project.id));
  const { data: suggestions, isMock } = await suggestCodes(interview.transcript, existingCodes.map((c) => c.name));

  for (const s of suggestions) {
    let code = existingCodes.find((c) => c.name.toLowerCase() === s.codeName.toLowerCase());
    if (!code) code = await createCode(project.id, s.codeName);
    await db.insert(codedSegments).values({
      interviewId,
      codeId: code.id,
      excerpt: isMock ? `[SUGESTÃO EM MODO DEMO] ${s.excerpt}` : s.excerpt,
      aiSuggested: true,
      confirmed: false,
      createdBy: user.id,
    });
  }
  revalidatePath(`/research/interviews`, "layout");
}
