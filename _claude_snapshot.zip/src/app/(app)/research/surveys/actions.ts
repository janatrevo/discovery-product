"use server";

import { db } from "@/db";
import { surveys, surveyQuestions, surveyResponses, surveyAnswers } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { getPageContext } from "@/lib/page-context";
import { checkLeadingQuestion } from "@/lib/bias-check";
import { linesToArray } from "@/lib/list-utils";
import { nanoid } from "nanoid";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";

export async function createSurvey(formData: FormData) {
  const { user, project, role } = await getPageContext();
  if (role === "viewer") throw new Error("Sem permissão.");
  const hypothesisId = String(formData.get("hypothesisId") || "") || null;

  const [created] = await db
    .insert(surveys)
    .values({
      projectId: project.id,
      hypothesisId,
      title: String(formData.get("title") || ""),
      objective: String(formData.get("objective") || ""),
      targetAudience: String(formData.get("targetAudience") || ""),
      sampleTarget: Number(formData.get("sampleTarget") || 30),
      createdBy: user.id,
    })
    .returning();

  revalidatePath("/research/surveys");
  redirect(`/research/surveys/${created.id}`);
}

export async function addQuestion(surveyId: string, formData: FormData) {
  const { role } = await getPageContext();
  if (role === "viewer") throw new Error("Sem permissão.");
  const questionText = String(formData.get("questionText") || "");
  const { leading, note } = checkLeadingQuestion(questionText);

  const [{ count }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(surveyQuestions)
    .where(eq(surveyQuestions.surveyId, surveyId));

  await db.insert(surveyQuestions).values({
    surveyId,
    orderIndex: count ?? 0,
    questionText,
    questionType: String(formData.get("questionType") || "open_text") as never,
    options: linesToArray(formData.get("options")),
    leadingFlag: leading,
    leadingFlagNote: note,
  });
  revalidatePath(`/research/surveys/${surveyId}`);
}

export async function deleteQuestion(surveyId: string, questionId: string) {
  const { role } = await getPageContext();
  if (role === "viewer") throw new Error("Sem permissão.");
  await db.delete(surveyQuestions).where(eq(surveyQuestions.id, questionId));
  revalidatePath(`/research/surveys/${surveyId}`);
}

export async function publishSurvey(surveyId: string) {
  const { role } = await getPageContext();
  if (role === "viewer") throw new Error("Sem permissão.");
  const slug = nanoid(10);
  await db.update(surveys).set({ status: "published", publicSlug: slug }).where(eq(surveys.id, surveyId));
  revalidatePath(`/research/surveys/${surveyId}`);
}

export async function closeSurvey(surveyId: string) {
  const { role } = await getPageContext();
  if (role === "viewer") throw new Error("Sem permissão.");
  await db.update(surveys).set({ status: "closed" }).where(eq(surveys.id, surveyId));
  revalidatePath(`/research/surveys/${surveyId}`);
}

// ---------- Resposta pública (sem autenticação) ----------
export async function submitSurveyResponse(slug: string, formData: FormData) {
  const [survey] = await db.select().from(surveys).where(eq(surveys.publicSlug, slug)).limit(1);
  if (!survey || survey.status !== "published") throw new Error("Pesquisa não disponível.");

  const questions = await db.select().from(surveyQuestions).where(eq(surveyQuestions.surveyId, survey.id));

  const [response] = await db.insert(surveyResponses).values({ surveyId: survey.id }).returning();

  const answerRows = questions
    .map((q) => {
      const raw = formData.getAll(`q_${q.id}`);
      if (raw.length === 0) return null;
      const value = q.questionType === "multi_choice" ? raw.map(String) : String(raw[0]);
      return { responseId: response.id, questionId: q.id, answerValue: value };
    })
    .filter(Boolean) as { responseId: string; questionId: string; answerValue: unknown }[];

  if (answerRows.length) await db.insert(surveyAnswers).values(answerRows);

  redirect(`/s/${slug}/obrigado`);
}
